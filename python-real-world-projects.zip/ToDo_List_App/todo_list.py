# To-Do List App using JSON Storage
import json

def load_tasks():
    try:
        with open('tasks.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []

def save_tasks(tasks):
    with open('tasks.json', 'w') as file:
        json.dump(tasks, file, indent=4)

def add_task():
    task = input("Enter new task: ")
    tasks = load_tasks()
    tasks.append({"task": task, "done": False})
    save_tasks(tasks)
    print("Task added.")

def view_tasks():
    tasks = load_tasks()
    if not tasks:
        print("No tasks found.")
        return
    for idx, task in enumerate(tasks, 1):
        status = "Done" if task["done"] else "Pending"
        print(f"{idx}. {task['task']} - {status}")

def mark_done():
    view_tasks()
    tasks = load_tasks()
    task_no = int(input("Enter task number to mark as done: "))
    if 0 < task_no <= len(tasks):
        tasks[task_no - 1]["done"] = True
        save_tasks(tasks)
        print("Task marked as done.")
    else:
        print("Invalid task number.")

while True:
    print("\n1. Add Task\n2. View Tasks\n3. Mark Task as Done\n4. Exit")
    choice = input("Enter choice: ")
    if choice == '1':
        add_task()
    elif choice == '2':
        view_tasks()
    elif choice == '3':
        mark_done()
    elif choice == '4':
        break
    else:
        print("Invalid choice.")