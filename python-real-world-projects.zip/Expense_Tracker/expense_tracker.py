# Expense Tracker CLI Tool
import csv

def add_expense():
    date = input("Enter date (YYYY-MM-DD): ")
    category = input("Enter category (Food, Transport, etc.): ")
    amount = float(input("Enter amount: "))
    with open('expenses.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([date, category, amount])
    print("Expense added successfully.")

def view_expenses():
    try:
        with open('expenses.csv', 'r') as file:
            reader = csv.reader(file)
            total = 0
            print("\nDate | Category | Amount")
            print("-" * 30)
            for row in reader:
                print(f"{row[0]} | {row[1]} | {row[2]}")
                total += float(row[2])
            print(f"\nTotal Expenses: {total}")
    except FileNotFoundError:
        print("No expenses found.")

while True:
    print("\n1. Add Expense\n2. View Expenses\n3. Exit")
    choice = input("Enter choice: ")
    if choice == '1':
        add_expense()
    elif choice == '2':
        view_expenses()
    elif choice == '3':
        break
    else:
        print("Invalid choice.")