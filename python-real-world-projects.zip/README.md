# Python Real-World Mini Projects

## 1. Expense Tracker CLI Tool
A simple command-line based expense manager to add and view daily expenses. Data is stored in a CSV file for tracking and analysis.

## 2. To-Do List App (JSON Storage)
A task management CLI app that allows users to add tasks, mark them as done, and maintain data persistence using a JSON file.